<?php
/**
 * The builder: the same client as the mobile app, laid out for a big screen.
 * A self-contained document; the marketing header and footer do not apply.
 *
 * Signed-out visitors see the sign-in gate. The account subscription from
 * Convex is the only thing that reveals the workspace.
 */

defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#121315">
<meta name="convex-url" content="<?php echo esc_attr( FORGE_CONVEX_URL ); ?>">
<meta name="forge-redirect" content="<?php echo esc_attr( home_url( '/app/' ) ); ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cpath fill='%23e9ebee' d='m16 2 5 5-3 3 10 8-6 12H10L4 18l10-8-3-3z'/%3E%3C/svg%3E">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<svg class="symbols" xmlns="http://www.w3.org/2000/svg"><defs>
<symbol id="menu" viewBox="0 0 256 256"><path fill="currentColor" stroke="none" d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"/></symbol>
<symbol id="gear" viewBox="0 0 256 256"><path fill="currentColor" stroke="none" d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm109.94-52.79a8,8,0,0,0-3.89-5.4l-29.83-17-.12-33.62a8,8,0,0,0-2.83-6.08,111.91,111.91,0,0,0-36.72-20.67,8,8,0,0,0-6.46.59L128,41.85,97.88,25a8,8,0,0,0-6.47-.6A112.1,112.1,0,0,0,54.73,45.15a8,8,0,0,0-2.83,6.07l-.15,33.65-29.83,17a8,8,0,0,0-3.89,5.4,106.47,106.47,0,0,0,0,41.56,8,8,0,0,0,3.89,5.4l29.83,17,.12,33.62a8,8,0,0,0,2.83,6.08,111.91,111.91,0,0,0,36.72,20.67,8,8,0,0,0,6.46-.59L128,214.15,158.12,231a7.91,7.91,0,0,0,3.9,1,8.09,8.09,0,0,0,2.57-.42,112.1,112.1,0,0,0,36.68-20.73,8,8,0,0,0,2.83-6.07l.15-33.65,29.83-17a8,8,0,0,0,3.89-5.4A106.47,106.47,0,0,0,237.94,107.21Zm-15,34.91-28.57,16.25a8,8,0,0,0-3,3c-.58,1-1.19,2.06-1.81,3.06a7.94,7.94,0,0,0-1.22,4.21l-.15,32.25a95.89,95.89,0,0,1-25.37,14.3L134,199.13a8,8,0,0,0-3.91-1h-.19c-1.21,0-2.43,0-3.64,0a8.08,8.08,0,0,0-4.1,1l-28.84,16.1A96,96,0,0,1,67.88,201l-.11-32.2a8,8,0,0,0-1.22-4.22c-.62-1-1.23-2-1.8-3.06a8.09,8.09,0,0,0-3-3.06l-28.6-16.29a90.49,90.49,0,0,1,0-28.26L61.67,97.63a8,8,0,0,0,3-3c.58-1,1.19-2.06,1.81-3.06a7.94,7.94,0,0,0,1.22-4.21l.15-32.25a95.89,95.89,0,0,1,25.37-14.3L122,56.87a8,8,0,0,0,4.1,1c1.21,0,2.43,0,3.64,0a8.08,8.08,0,0,0,4.1-1l28.84-16.1A96,96,0,0,1,188.12,55l.11,32.2a8,8,0,0,0,1.22,4.22c.62,1,1.23,2,1.8,3.06a8.09,8.09,0,0,0,3,3.06l28.6,16.29A90.49,90.49,0,0,1,222.9,142.12Z"/></symbol>
<symbol id="plus" viewBox="0 0 24 24"><path d="M12 4v16M4 12h16"/></symbol>
<symbol id="close" viewBox="0 0 24 24"><path d="m5 5 14 14M19 5 5 19"/></symbol>
<symbol id="mic" viewBox="0 0 24 28"><rect x="8" y="2" width="8" height="16" rx="4"/><path d="M4 12v3a8 8 0 0 0 16 0v-3M12 23v3"/></symbol>
<symbol id="send" viewBox="0 0 24 24"><path d="M4 12h15M13 6l6 6-6 6"/></symbol>
<symbol id="chevron" viewBox="0 0 24 24"><path d="m9 5 6 7-6 7"/></symbol>
<symbol id="check" viewBox="0 0 24 24"><path d="m3 12 6 6L22 5"/></symbol>
<symbol id="camera" viewBox="0 0 24 24"><path d="M3 6h4l2-3h6l2 3h4a1 1 0 0 1 1 1v13H2V7a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13" r="4"/></symbol>
<symbol id="photo" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m7 21 10-10 4 4"/></symbol>
<symbol id="clip" viewBox="0 0 24 24"><path d="m20 11-9 10a6 6 0 0 1-8-8L13 3a4 4 0 0 1 6 6L9 19a2 2 0 0 1-3-3L16 6"/></symbol>
<symbol id="chevron-down" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></symbol>
<symbol id="chevron-left" viewBox="0 0 24 24"><path d="m15 5-7 7 7 7"/></symbol>
<symbol id="mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></symbol>
<symbol id="google" viewBox="0 0 24 24"><path d="M21 12.5h-8.5"/><path d="M20.5 12.5A8.5 8.5 0 1 1 18 6"/></symbol>
<symbol id="apple" viewBox="0 0 24 24"><path fill="currentColor" stroke="none" d="M16.37 12.7c0-2.5 2.05-3.7 2.14-3.76-1.17-1.7-2.98-1.94-3.62-1.97-1.54-.16-3.01.9-3.79.9-.78 0-1.99-.88-3.27-.86-1.68.03-3.23.98-4.1 2.48-1.75 3.03-.45 7.52 1.26 9.98.83 1.2 1.82 2.55 3.12 2.5 1.25-.05 1.72-.81 3.23-.81s1.94.81 3.26.78c1.35-.02 2.2-1.22 3.02-2.43.95-1.39 1.34-2.74 1.36-2.81-.03-.01-2.61-1-2.61-3.97zM13.9 5.4c.69-.84 1.16-2 1.03-3.16-1 .04-2.2.66-2.92 1.5-.64.74-1.2 1.93-1.05 3.07 1.11.09 2.25-.57 2.94-1.41z"/></symbol>
<symbol id="external" viewBox="0 0 24 24"><path d="M14 4h6v6M20 4l-9 9M19 14v6H4V5h6"/></symbol>
<symbol id="globe" viewBox="0 0 256 256" stroke-width="16"><circle cx="128" cy="128" r="96"/><path d="M37.5 96h181M37.5 160h181"/><ellipse cx="128" cy="128" rx="40" ry="93.4"/></symbol>
</defs></svg>

<section id="auth-gate" class="auth-gate" aria-label="Sign in" data-home="<?php echo esc_url( home_url( '/?home' ) ); ?>" data-panel="<?php echo esc_url( forge_img( 'auth-panel.jpg' ) ); ?>"></section>

<main class="app" hidden inert>
<button class="hamburger" aria-label="Open navigation" data-open="navigation" aria-haspopup="dialog"><svg><use href="#menu"/></svg></button>

<section class="navigation" role="dialog" aria-modal="true" aria-label="Navigation menu" hidden>
<div class="nav-brand"><a class="nav-brand-link" href="<?php echo esc_url( home_url( '/?home' ) ); ?>" aria-label="Forge Nexxus"><?php echo forge_mark( 'nav-mark' ); ?><span>Forge Nexxus</span></a><button class="nav-close dismiss" type="button" aria-label="Close navigation"><svg><use href="#close"/></svg></button></div>
<div class="nav-content">
<button class="new-site" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><span>New site</span></button>
<p class="nav-section-label">Your sites</p>
<div class="site-list" aria-label="Your sites"></div>
<p class="sites-empty" hidden>Your sites will show up here. Describe one to get started.</p>
<p class="sites-error" role="alert" hidden></p>
</div>
<div class="settings-content" id="settings-content" hidden>
<button class="settings-back"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12H4m7-7-7 7 7 7"/></svg><span>Back</span></button>
<div class="settings-list">
<h3 class="settings-group">Account</h3>
<button class="open-profile" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="6" r="4"/><path d="M5 22v-3a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v3"/></svg><span>Profile</span></button>
<button class="open-appearance" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20h1a2 2 0 0 0 1-4 2 2 0 0 1 1-4h3a4 4 0 0 0 4-4 10 10 0 0 0-10-8Z"/><circle cx="7" cy="9" r=".7"/><circle cx="11" cy="6" r=".7"/><circle cx="16" cy="7" r=".7"/><circle cx="6" cy="14" r=".7"/></svg><span>Appearance</span></button>
<h3 class="settings-group">Plan</h3>
<button class="open-plan" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="4" width="20" height="15" rx="2"/><path d="M2 9h20M6 15h4"/></svg><span>Plan &amp; credits</span><span class="settings-value" data-settings-plan></span></button>
<button class="open-usage" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20V11M10 20V4M16 20v-7M2 20h20"/></svg><span>Usage</span></button>
<h3 class="settings-group">Sites</h3>
<button class="open-domains" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg><span>Domains</span><span class="settings-value" data-settings-domains hidden></span></button>
<h3 class="settings-group">Clients</h3>
<a class="settings-link" href="<?php echo esc_url( FORGE_MOBILE_APP_URL ); ?>" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/></svg><span>Mobile app</span><svg class="settings-external" viewBox="0 0 24 24" aria-hidden="true"><use href="#external"/></svg></a>
</div>
</div>
<div class="credits-card" hidden>
<button class="credits-summary" type="button" aria-label="Plan and credits">
<span class="credits-head"><span data-credits-plan>Free plan</span><span class="credits-count"><strong data-credits-available>0</strong><span data-credits-granted> of 0</span></span></span>
<span class="credits-bar" aria-hidden="true"><span class="credits-fill" data-credits-fill></span></span>
<span class="credits-resets" data-credits-resets></span>
</button>
<button class="credits-cta" type="button" data-credits-cta>Upgrade</button>
</div>
<footer class="nav-footer"><button class="profile" data-open="account" aria-haspopup="dialog"><span class="avatar" data-account-avatar>G</span><span data-account-label>Guest</span></button><button class="settings" aria-label="Settings" aria-expanded="false" aria-controls="settings-content"><svg aria-hidden="true"><use href="#gear"/></svg></button></footer>
</section>

<section class="workspace">
<header class="workspace-bar">
<span class="workspace-site"><strong data-site-name></strong><small data-site-status></small></span>
<span class="workspace-hint">Forge Nexxus · web</span>
<button class="globe-button" type="button" aria-label="Site address and domains" data-open="address" aria-haspopup="dialog" hidden><svg><use href="#globe"/></svg></button>
</header>
<div class="thread-column">
<div class="greeting"><svg class="forge-mark" viewBox="0 0 24 30" aria-hidden="true"><path fill="currentColor" d="m12 0 5 5-3 3 10 7-6 15H6L0 15l10-7-3-3Z"/></svg><h1 data-greeting>What will you build today?</h1><p class="greeting-sub">Describe a website and Forge builds it.</p></div>
<section class="thread" role="log" aria-label="Build thread" aria-live="polite"></section>
<div class="composer-area"><p class="composer-error" role="alert" hidden></p><div class="attachment-tray" aria-label="Attached files" hidden></div><div class="site-bar" hidden><span class="site-bar-copy"><strong data-site-name></strong><small data-site-status></small></span><button class="globe-button" type="button" aria-label="Site address and domains" data-open="address" aria-haspopup="dialog" hidden><svg><use href="#globe"/></svg></button><button class="site-bar-preview" type="button">Preview</button></div><div class="composer"><textarea aria-label="Describe your site" placeholder="Describe the site you want…" rows="1" autocapitalize="sentences" autocomplete="off" spellcheck="true"></textarea><div class="toolbar"><button class="add" data-open="attachments" aria-label="Add images or files" aria-haspopup="dialog"><svg><use href="#plus"/></svg></button><button class="microphone" type="button" aria-label="Start voice input" aria-pressed="false"><svg><use href="#mic"/></svg></button><button class="send" type="button" aria-label="Send"><svg><use href="#send"/></svg></button></div></div><p class="composer-hint">Enter to send · Shift+Enter for a new line</p></div>
</div>
<section class="overlay preview" data-back=".preview-back" role="dialog" aria-modal="true" aria-labelledby="preview-title" hidden>
<header class="appearance-header"><button class="appearance-back preview-back" type="button" aria-label="Back to the thread"><svg><use href="#chevron-left"/></svg></button><h2 id="preview-title" data-site-name="Preview">Preview</h2><span class="preview-live">Live preview</span></header>
<div class="preview-frame"><iframe class="preview-iframe" title="Site preview" sandbox="" referrerpolicy="no-referrer"></iframe><p class="preview-empty" hidden>Nothing built yet. Describe your site and Forge will make a first version.</p></div>
<footer class="preview-footer">
<p class="preview-status" data-preview-status></p>
<a class="preview-link" data-preview-link href="#" target="_blank" rel="noopener" hidden></a>
<div class="preview-actions"><button class="chip-button preview-publish" type="button">Publish</button><button class="row-button preview-download" type="button" hidden>Download code</button><button class="row-button preview-unpublish" type="button" hidden>Unpublish</button></div>
<p class="overlay-error" role="alert" hidden></p>
</footer>
</section>
</section>

<button class="backdrop" aria-label="Close menu" hidden></button>
<div class="status-shield" aria-hidden="true"></div>
<div class="modal-scrim" hidden></div>

<section class="sheet attachments" role="dialog" aria-modal="true" aria-labelledby="context-title" hidden><div class="handle"></div><header><button class="dismiss" aria-label="Close attachments"><svg><use href="#close"/></svg></button><h2 id="context-title">Attach</h2></header>
<p class="sheet-copy">Add photos, a logo or files for Forge to use in your site.</p>
<div class="group add-list">
<button type="button" data-pick="camera"><svg><use href="#camera"/></svg><span>Camera</span></button>
<button type="button" data-pick="photos"><svg><use href="#photo"/></svg><span>Photos</span></button>
<button type="button" data-pick="files"><svg><use href="#clip"/></svg><span>Files</span><svg class="chevron"><use href="#chevron"/></svg></button>
</div>
<p class="sheet-note">Images up to 10 MB. Text files and PDFs are read; Forge can place your pictures in the page.</p>
<p class="attach-error" role="alert" hidden></p>
<input class="picker" type="file" accept="image/*" capture="environment" data-input="camera" hidden>
<input class="picker" type="file" accept="image/*" multiple data-input="photos" hidden>
<input class="picker" type="file" accept="image/*,text/plain,text/markdown,text/csv,text/html,text/css,application/json,application/xml,application/pdf,.md,.markdown,.txt,.csv,.json,.xml,.html,.css,.js,.svg,.pdf" multiple data-input="files" hidden>
</section>

<section class="sheet account" role="dialog" aria-modal="true" aria-labelledby="account-title" hidden><div class="handle"></div><header><button class="dismiss" aria-label="Close account"><svg><use href="#close"/></svg></button><h2 id="account-title">Account</h2></header>
<div class="account-guest">
<p class="account-copy">Sign in to build. Your sites, credits and settings follow your account on every device.</p>
<form class="account-email"><div class="search"><svg><use href="#mail"/></svg><input type="email" name="email" placeholder="Email address" autocomplete="email" inputmode="email" required aria-label="Email address"></div><button type="submit" class="account-button">Email me a sign-in link</button></form>
<p class="account-sent" hidden>Check your inbox for a sign-in link. It works on this device only.</p>
<h3>Or continue with</h3>
<div class="group account-providers"><button type="button" data-provider="google"><svg><use href="#google"/></svg><span>Google</span><svg class="chevron"><use href="#chevron"/></svg></button><button type="button" data-provider="apple"><svg><use href="#apple"/></svg><span>Apple</span><svg class="chevron"><use href="#chevron"/></svg></button></div>
</div>
<div class="account-member" hidden>
<div class="group"><div class="account-identity"><span class="avatar" data-account-avatar>?</span><span class="account-copy-block"><strong data-account-name></strong><small data-account-email></small></span></div></div>
<button type="button" class="account-button account-signout">Sign out</button><p class="account-error" role="alert" hidden></p>
</div>
</section>

<section class="sheet address" role="dialog" aria-modal="true" aria-labelledby="address-title" hidden><div class="handle"></div><header><button class="dismiss" aria-label="Close domains"><svg><use href="#close"/></svg></button><h2 id="address-title">Domain</h2></header>
<div class="address-upsell" hidden>
<p class="sheet-copy">Free is for planning and building. Putting your site on an address of its own<span data-address-upsell-domain></span>, and pointing a domain you already own at it, come with the <span data-address-upsell-plan></span> plan.</p>
<button type="button" class="account-button open-plan-from-address">See plans</button>
</div>
<div class="address-body">
<p class="sheet-copy">Your site's address on the web. Pick the name, then point your own domain at it.</p>
<h3 class="address-heading">Forge address</h3>
<form class="address-form">
<div class="address-field"><input class="address-slug" name="slug" placeholder="your-site" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="40" aria-label="Site address" required><span class="address-suffix" data-address-domain></span></div>
<button class="chip-button address-save" type="submit">Save</button>
</form>
<p class="address-note" data-address-note></p>
<p class="address-note address-warning" hidden>Changing this breaks the old address: <span data-address-old></span> stops answering, and any domain pointed at it needs the new one.</p>
<a class="address-live" data-address-live href="#" target="_blank" rel="noopener" hidden></a>
<h3 class="address-heading">Custom domain</h3>
<form class="address-domain-form" hidden>
<div class="address-field"><input class="address-host" name="hostname" placeholder="www.example.com" autocomplete="off" autocapitalize="none" spellcheck="false" inputmode="url" aria-label="Your domain" required></div>
<button class="chip-button address-add" type="submit">Add</button>
</form>
<p class="sheet-copy address-gate" hidden>Custom domains come with the <span data-address-plan></span> plan and up. <button class="link-button open-plan-from-address" type="button">See plans</button></p>
<div class="group address-domains" data-address-domains></div>
<p class="sheet-copy address-empty" hidden>No custom domain yet. Adding one shows the single DNS record to copy.</p>
</div>
<p class="address-error" role="alert" hidden></p>
</section>

<section class="appearance" role="dialog" aria-modal="true" aria-labelledby="appearance-title" hidden>
<header class="appearance-header"><button class="appearance-back" type="button" aria-label="Back to Settings"><svg><use href="#chevron-left"/></svg></button><h2 id="appearance-title">Appearance</h2></header>
<div class="appearance-scroll">
<div class="appearance-card theme-card">
<div class="appearance-row"><div class="appearance-copy"><strong>Theme</strong><p>Choose between light and dark.</p></div>
<button class="theme-select" type="button" aria-haspopup="listbox" aria-expanded="false" aria-controls="theme-menu"><span data-theme-label>Dark</span><svg><use href="#chevron-down"/></svg></button></div>
<div class="theme-menu" id="theme-menu" role="listbox" aria-label="Theme" hidden>
<button type="button" role="option" data-theme="light">Light</button>
<button type="button" role="option" data-theme="dark" aria-selected="true">Dark</button>
</div></div>
<h3>Build thread</h3>
<div class="appearance-stack">
<div class="appearance-row density"><div class="density-head"><div class="appearance-copy"><strong>Detail level</strong><p>How much of each build step is shown</p></div>
<div class="density-slider"><input class="density-range" type="range" min="0" max="100" value="64" data-setting="density" aria-label="Detail level"></div></div>
<div class="density-scale"><span>Compact</span><span>Detailed</span></div></div>
<div class="appearance-row"><div class="appearance-copy"><strong>Code Block Word Wrap</strong><p>Wrap long lines in code blocks</p></div>
<button class="toggle" type="button" data-setting="codeWrap" aria-pressed="false" aria-label="Code Block Word Wrap"></button></div>
<div class="appearance-row"><div class="appearance-copy"><strong>Themed Diff Backgrounds</strong><p>Use themed background colors for inline code diffs</p></div>
<button class="toggle" type="button" data-setting="themedDiff" aria-pressed="true" aria-label="Themed Diff Backgrounds"></button></div>
</div>
<h3>Colors</h3>
<div class="appearance-stack">
<div class="appearance-row"><div class="appearance-copy"><strong>Reduce Transparency</strong><p>Replace translucent surfaces with opaque backgrounds</p></div>
<button class="toggle reduce-transparency" type="button" data-setting="reduceTransparency" aria-pressed="true" aria-label="Reduce Transparency"></button></div>
</div>
<h3>Typography</h3>
<div class="appearance-stack">
<div class="appearance-row"><div class="appearance-copy"><strong>Type size</strong><p>Fixed at 16px — same scale as the mobile app</p></div><span class="type-size">16</span></div>
<div class="appearance-row font-row"><div class="appearance-copy"><strong>UI Font Family</strong><p>Override the Forge Nexxus user interface typeface</p></div>
<button class="font-select" type="button" aria-haspopup="listbox" aria-expanded="false" aria-controls="ui-font-menu" data-font-menu="ui-font-menu" data-setting="uiFont"><span>System font</span><svg><use href="#chevron-down"/></svg></button>
<div class="font-menu" id="ui-font-menu" role="listbox" aria-label="UI Font Family" hidden><button type="button" role="option" aria-selected="true">System font</button></div></div>
<div class="appearance-row font-row"><div class="appearance-copy"><strong>Code Font Family</strong><p>Override the font for code editors and diffs</p></div>
<button class="font-select" type="button" aria-haspopup="listbox" aria-expanded="false" aria-controls="code-font-menu" data-font-menu="code-font-menu" data-setting="codeFont"><span>System monospace</span><svg><use href="#chevron-down"/></svg></button>
<div class="font-menu" id="code-font-menu" role="listbox" aria-label="Code Font Family" hidden><button type="button" role="option" aria-selected="true">System monospace</button></div></div>
</div>
</div>
</section>

<section class="overlay profile-screen" data-back=".profile-back" role="dialog" aria-modal="true" aria-labelledby="profile-title" hidden>
<header class="appearance-header"><button class="appearance-back profile-back" type="button" aria-label="Back to Settings"><svg><use href="#chevron-left"/></svg></button><h2 id="profile-title">Profile</h2></header>
<div class="appearance-scroll">
<div class="profile-identity"><span class="avatar avatar-large" data-account-avatar>?</span><strong data-account-name></strong><small data-account-email></small></div>
<h3>Name</h3>
<form class="appearance-stack profile-form"><div class="appearance-row"><input class="text-field" name="name" placeholder="Your name" maxlength="80" autocomplete="name" aria-label="Your name"><button class="chip-button" type="submit">Save</button></div></form>
<h3>Sign-in methods</h3>
<div class="appearance-stack provider-list" data-provider-list></div>
<p class="overlay-note" data-provider-empty hidden>Sign in with email, Google or Apple to link a method.</p>
<h3>Account</h3>
<div class="appearance-stack"><button class="row-button profile-signout" type="button">Sign out</button><button class="row-button danger profile-delete" type="button">Delete account</button></div>
<p class="overlay-note">Deleting your account removes your sites, domains, credits and history. It cannot be undone.</p>
<p class="overlay-error" role="alert" hidden></p>
</div>
</section>

<section class="overlay plan" data-back=".plan-back" role="dialog" aria-modal="true" aria-labelledby="plan-title" hidden>
<header class="appearance-header"><button class="appearance-back plan-back" type="button" aria-label="Back to Settings"><svg><use href="#chevron-left"/></svg></button><h2 id="plan-title">Plan &amp; credits</h2></header>
<div class="appearance-scroll">
<div class="appearance-card plan-current">
<div class="appearance-row"><div class="appearance-copy"><strong data-plan-name>Free plan</strong><p data-plan-renews></p></div><span class="plan-price-tag" data-plan-price></span></div>
<div class="credits-meter"><div class="credits-head"><span data-plan-meter-label>Credits remaining</span><strong data-plan-meter>0 of 0</strong></div><div class="credits-bar" aria-hidden="true"><span class="credits-fill" data-plan-fill></span></div><p class="credits-resets" data-plan-resets></p></div>
<div class="plan-actions"><button class="row-button plan-billing" type="button" hidden>Manage billing</button><button class="row-button plan-cancel" type="button" hidden>Move to Free when this period ends</button><button class="row-button plan-resume" type="button" hidden>Keep my plan</button><p class="overlay-note plan-scheduled" hidden>Moving to Free on <span data-plan-end></span>. Your credits stay until then.</p></div>
</div>
<h3>Plans</h3>
<div class="plan-cards" data-plan-cards></div>
<h3 class="topup-heading">Top up</h3>
<div class="appearance-stack" data-topup-list></div>
<p class="overlay-note topup-note">Top-up credits join this period's balance and expire with it.</p>
<p class="overlay-error" role="alert" hidden></p>
</div>
</section>

<section class="overlay usage" data-back=".usage-back" role="dialog" aria-modal="true" aria-labelledby="usage-title" hidden>
<header class="appearance-header"><button class="appearance-back usage-back" type="button" aria-label="Back to Settings"><svg><use href="#chevron-left"/></svg></button><h2 id="usage-title">Usage</h2></header>
<div class="appearance-scroll">
<div class="appearance-card"><div class="appearance-row"><div class="appearance-copy"><strong data-usage-headline>This period</strong><p data-usage-sub></p></div></div></div>
<h3>Activity</h3>
<div class="appearance-stack ledger" data-ledger></div>
<p class="overlay-note" data-ledger-empty hidden>Nothing yet. Credits show up here as you build.</p>
</div>
</section>

<section class="overlay domains" data-back=".domains-back" role="dialog" aria-modal="true" aria-labelledby="domains-title" hidden>
<header class="appearance-header"><button class="appearance-back domains-back" type="button" aria-label="Back to Settings"><svg><use href="#chevron-left"/></svg></button><h2 id="domains-title">Domains</h2></header>
<div class="appearance-scroll">
<form class="appearance-stack domain-form" hidden>
<div class="appearance-row"><select class="text-field" name="siteId" aria-label="Site" required></select></div>
<div class="appearance-row"><input class="text-field" name="hostname" placeholder="www.example.com" autocomplete="off" autocapitalize="none" spellcheck="false" inputmode="url" aria-label="Domain" required><button class="chip-button" type="submit">Add</button></div>
</form>
<p class="overlay-note domain-gate" hidden>Custom domains come with the <span data-domain-plan></span> plan and up. <button class="link-button open-plan-from-domains" type="button">See plans</button></p>
<p class="overlay-note domain-nosites" hidden>Create a site first, then point a domain at it.</p>
<h3>Your domains</h3>
<div class="appearance-stack domain-list" data-domain-list></div>
<p class="overlay-note" data-domain-empty hidden>No custom domains yet.</p>
<p class="overlay-note">A domain stays pending until publishing verifies its DNS.</p>
<p class="overlay-error" role="alert" hidden></p>
</div>
</section>
</main>
<?php wp_footer(); ?>
</body>
</html>
